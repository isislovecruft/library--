#  
# ADN Connections  
# Usage: adn-connections.pl  [-c|-s|-a] [-u <user>] [-p <password>]  ProxySG-IP[:port]
# modified by Blue Coat Systems, Dieter Mueller
# 
# 	option -c ProxyClient connections
#	option -s ProxySG connections
#	option -a overall connections
#	option -u <user> username for basic HTTP authentication 
#	option -p <password> password for basic HTTP authentication 
# 
 
require 5.004_04; 
#because that's the one that works with NT 
 
use strict; 
use vars qw($opt_c $opt_s $opt_a $opt_u $opt_p); 
use Getopt::Std; 
use LWP::UserAgent; 
use URI::URL; 
use HTTP::Status; 
 
my ($user, $password); 
my ($cacheName); 
my $sg; # number of connected SG
my $pc; #number of connected proxyclient
my $connections; #number of adn connections 
my %tags; 
 
sub snarf { # html section 
   my($cache, $path) = @_; 
    my $url; 
    if (index($cache, 'http://') == 0) { 
		$url = url($cache); 
    } else { 
		$url = url('http://' . $cache); 
    } 
    $url->path($path);
    my $ua = new LWP::UserAgent;
     
    $ua->timeout(30);		# 30 second timeout 
    my $request = new HTTP::Request GET => $url; 
	$request->authorization_basic( $user, $password ); 
    $request->push_header('Pragma', 'no-cache'); 
    my $response = $ua->simple_request($request); 
    if ($response->is_success) { 
		if ($response->code != RC_OK) { 
			print STDERR "Could not GET ", $url, "\n"; 
		} else { 
			# split out into lines 
			my @lines = $response->content =~ m/^.*$/gmo; 
			# parse lines 
			my($tag, $value, $line); 
			foreach $line (@lines) {
				$line =~ s/&nbsp;/ /g; 
				$line =~ s/<BR>//g; 
				$line =~ s/^\s+//;
				if ($line =~ "____Peers:") { 
					($tag, $value) = split(" ", $line); 
					$value =~ s/^\s+//;
					($sg, $pc) = split("/",$value);
				}
				if ($line =~ "BDC_Perf_Stats_0030") { 
					($tag, $value) = split(" ", $line); 
					$value =~ s/^\s+//;
					$connections = $value;	
				} 
			} 
		} 
		  
    } else { 
		print STDERR "Value ", $url, "\n"; 
    } 
    return; 
} 
 
sub help { 
    die "usage: $0 [-c|-s|-a] [-u <username>] [-p <password>] ProxySG-IP[:port]\n"; 
} 
 
# MAIN 
if( @ARGV < 1 ) { 
	&help; 
} 
getopts('csau:p:'); 
$user =			$opt_u; 
$password =		$opt_p; 
$cacheName = shift; 
 
if( $cacheName !~ m/:/ ) { 
	$cacheName .= ":8081"; 
} 
snarf($cacheName, '/Console_urls/stats_mode=0' ); # obfuscated stats pages 
snarf($cacheName, '/ADN/show/dashboard');
snarf($cacheName, '/ADN/show/perf');
if ($opt_c) {
print "$pc\n";
}
if ($opt_s) {
print "$sg\n";
}
if ($opt_a) {
print "$connections\n";
}
 
exit 0; 
