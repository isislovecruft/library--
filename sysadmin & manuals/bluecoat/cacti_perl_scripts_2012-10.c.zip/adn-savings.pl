#  
# ADN Connections  
# Usage: adn-savings.pl [-u <user>] [-p <password>]  ProxySG-IP[:port]
# modified by Blue Coat Systems, Dieter Mueller
#
# #	option -u <user> username for basic HTTP authentication 
#	option -p <password> password for basic HTTP authentication 
# 
 
require 5.004_04; 
#because that's the one that works with NT 
 
use strict; 
use vars qw($opt_u $opt_p); 
use Getopt::Std; 
use LWP::UserAgent; 
use URI::URL; 
use HTTP::Status; 
 
my ($user, $password); 
my ($cacheName); 
my $optimized; # inbound_compressed
my $unoptimized;
my $savings;
my %tags; 
 
sub snarf { # html section 
   my($cache, $path) = @_; 
    my $url; 
    if (index($cache, 'http://') == 0) { 
		$url = url($cache); 
    } else { 
		$url = url('http://' . $cache); 
    } 
    $url->path($path);
    my $ua = new LWP::UserAgent;
     
    $ua->timeout(30);		# 30 second timeout 
    my $request = new HTTP::Request GET => $url; 
	$request->authorization_basic( $user, $password ); 
    $request->push_header('Pragma', 'no-cache'); 
    my $response = $ua->simple_request($request); 
    if ($response->is_success) { 
		if ($response->code != RC_OK) { 
			print STDERR "Could not GET ", $url, "\n"; 
		} else { 
			# split out into lines 
			my @lines = $response->content =~ m/^.*$/gmo; 
			# parse lines 
			my($tag, $value, $line);
			my @tags; 
			foreach $line (@lines) {
				$line =~ s/&nbsp;/ /g;
 
				$line =~ s/^\s+//;
				if ($line =~ "adn:traffic:total:optimized_bytes~hourly") { 
					($tag, $value) = split("60, 60", $line);			 
					@tags = split(" ", $value);
					$optimized = $tags[60];
				}
				if ($line =~ "adn:traffic:total:unoptimized_bytes~hourly") { 
					($tag, $value) = split("60, 60", $line);			
					@tags = split(" ", $value);
					$unoptimized = $tags[60];
				}
				 
			} 
		} 
		  
    } else { 
		print STDERR "Value ", $url, "\n"; 
    } 
    return; 
} 
 
sub help { 
    die "usage: $0 [-i|o] [-c|-n] [-u <username>] [-p <password>] ProxySG-IP[:port]\n"; 
} 
 
# MAIN 
if( @ARGV < 1 ) { 
	&help; 
} 
getopts('iocu:np:'); 
$user =			$opt_u; 
$password =		$opt_p; 
$cacheName = shift; 
 
if( $cacheName !~ m/:/ ) { 
	$cacheName .= ":8081"; 
}
 
snarf($cacheName, '/Console_urls/stats_mode=0' ); # obfuscated stats pages
snarf($cacheName, '/PDM/show-values/adn:traffic:total:unoptimized_bytes~hourly');
snarf($cacheName, '/PDM/show-values/adn:traffic:total:optimized_bytes~hourly');
$savings = sprintf("%.1f",($unoptimized - $optimized) / $unoptimized * 100);
print "$savings\n";
exit 0; 
