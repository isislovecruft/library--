

#  
# ProxySG HTTP Client Workers 
# Usage: proxySG_workers.pl [-u <user>] [-p <password>]  ProxySG-IP[:port]
# modified by Blue Coat Systems, Dieter Mueller
#
#	option -u <user> username for basic HTTP authentication 
#       option -p <password> password for basic HTTP authentication 
#
#   	Return 1      current state of the 'workers'
#   	Return 2      current state of the 'max workers'

require 5.004_04;		#because that's the one that works with NT

use strict;
#use vars qw($opt_t $opt_h $opt_u $opt_p);
use vars qw($opt_u $opt_p);
use Getopt::Std;
use LWP::UserAgent;
use URI::URL;
use HTTP::Status;

my( $user, $password );
my ($cacheName, $Port, $uptime);
my $current_workers;
my $max_workers;
my %tags = ("HTTP_MAIN_0090", 0,        #max workers
            "HTTP_MAIN_0091", 0,        #current workers
	);

sub snarf {
    my($cache, $path, $port) = @_;
    my $url;
    if (!($port)) {$port = 8081; }

    if (index($cache, 'http://') == 0) {
	$url = url($cache . ':' . $port);
    } else {
	$url = url('http://' . $cache . ':' . $port);
    }
    $url->path($path);
    my $ua = new LWP::UserAgent;
    $ua->timeout(30);		# 30 second timeout
    my $request = new HTTP::Request GET => $url;
	$request->authorization_basic( $user, $password );
    $request->push_header('Pragma', 'no-cache'); # 
    my $response = $ua->simple_request($request);
    if ($response->is_success) {
	if ($response->code != RC_OK) {
	    print STDERR "Could not GET ", $url, "\n";
	} else {
	    # split out into lines
	    my @lines = $response->content =~ m/^.*$/gmo;
	    # parse lines
	    my($tag, $value, $line);
	    foreach $line (@lines) {
		($tag, $value) = split(/      /, $line, 2);
		if ($tag eq "HTTP_MAIN_0090")
		{
		    $tags{HTTP_MAIN_0090} = $value;
		}
		if ($tag eq "HTTP_MAIN_0091")
		{
		    $tags{HTTP_MAIN_0091} = $value;
		}
		if ($tags{$tag} == 0) {
		    $tags{$tag} = $value;
		    $tags{$tag} =~ s/,//g;
		}
	    }
	}
    } else {
	print STDERR "Could not GET ", $url, "\n";
    }
    return;
}

sub help {
    die "usage: $0 [-u <username>] [-p <password>] ProxySG-IP[:port]\n";
}

# MAIN
if( @ARGV < 1 ) {
 	&help;
}

getopts('htu:p:');
$user =			$opt_u;
$password =		$opt_p;

$cacheName = shift;

if( $cacheName !~ m/:/ ) {
	$cacheName .= ":8081";
}
snarf($cacheName, '/Console_urls/stats_mode=0' ); # obfuscated stats pages
snarf($cacheName, '/HTTP/Statistics', $Port);


#Do the hit ratio for both objects and bytes
if (!($tags{HTTP_MAIN_0090})) {$tags{HTTP_MAIN_0090} = 10;}
if (!($tags{HTTP_MAIN_0091})) {$tags{HTTP_MAIN_0091} = 10;}

$current_workers = sprintf("%d", $tags{HTTP_MAIN_0091}); 

$max_workers = sprintf("%d", $tags{HTTP_MAIN_0090});

#output results
print("workers:$current_workers max:$max_workers\n");

exit 0;
