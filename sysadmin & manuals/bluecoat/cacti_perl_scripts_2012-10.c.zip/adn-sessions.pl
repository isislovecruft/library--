#  
# ADN Sessions  
# Usage: adn-sessions.pl [-c|-a]   [-u <user>] [-p <password>]  ProxySG-IP[:port]
# modified by Blue Coat Systems, Dieter Mueller
# 
# 	option -c for overall active sessions 
#	option -a for active ADN sessions 
#	option -u <user> username for basic HTTP authentication 
#	option -p <password> password for basic HTTP authentication 
# 
 
require 5.004_04; 
#because that's the one that works with NT 
 
use strict; 
use vars qw($opt_c $opt_a $opt_u $opt_p); 
use Getopt::Std; 
use LWP::UserAgent; 
use URI::URL; 
use HTTP::Status; 
 
my ($user, $password); 
my ($cacheName); 
my $active; # number of connected SG
my $adn; #number of connected proxyclient 
my %tags; 
 
sub snarf { # html section 
   my($cache, $path) = @_; 
    my $url; 
    if (index($cache, 'http://') == 0) { 
		$url = url($cache); 
    } else { 
		$url = url('http://' . $cache); 
    } 
    $url->path($path);
    my $ua = new LWP::UserAgent;
     
    $ua->timeout(30);		# 30 second timeout 
    my $request = new HTTP::Request GET => $url; 
	$request->authorization_basic( $user, $password ); 
    $request->push_header('Pragma', 'no-cache'); 
    my $response = $ua->simple_request($request); 
    if ($response->is_success) { 
		if ($response->code != RC_OK) { 
			print STDERR "Could not GET ", $url, "\n"; 
		} else { 
			# split out into lines 
			my @lines = $response->content =~ m/^.*$/gmo; 
			# parse lines 
			my($tag, $value, $line); 
			foreach $line (@lines) {
				$line =~ s/&nbsp;/ /g;
 
				$line =~ s/^\s+//;
				if ($line =~ "Number of Active Sessions:") { 
					($tag, $value) = split("Number of Active Sessions: ", $line);				 
					($tag, $value) = split("<br>", $value);
					$active = $tag;
				}
				if ($line =~ "Number of ADN Sessions:") { 
					($tag, $value) = split("Number of ADN Sessions: ", $line); 
					($tag, $value) = split("<br>", $value);
					$adn = $tag;
				}
 
			} 
		} 
		  
    } else { 
		print STDERR "Value ", $url, "\n"; 
    } 
    return; 
} 
 
sub help { 
    die "usage: $0 [-c|-a] [-u <username>] [-p <password>] ProxySG-IP[:port]\n"; 
} 
 
# MAIN 
if( @ARGV < 1 ) { 
	&help; 
} 
getopts('cau:p:'); 
$user =			$opt_u; 
$password =		$opt_p; 
$cacheName = shift; 
 
if( $cacheName !~ m/:/ ) { 
	$cacheName .= ":8081"; 
} 
snarf($cacheName, '/Console_urls/stats_mode=0' ); # obfuscated stats pages 
snarf($cacheName, '/AS/Statistics');
if ($opt_c) {
print "$active\n";
}
if ($opt_a) {
print "$adn\n";
} 
exit 0; 
