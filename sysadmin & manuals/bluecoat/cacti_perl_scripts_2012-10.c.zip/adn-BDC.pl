#  
# ADN Connections  
# Usage: adn-bdc.pl [-i|o] [-c|-n] [-u <user>] [-p <password>]  ProxySG-IP[:port]
# modified by Blue Coat Systems, Dieter Mueller
#
#	option -i incoming BDC 
#	option -o outgoing BDC
#	option -c compressed BDC 
#	option -n uncompressed BDC 
#	option -u <user> username for basic HTTP authentication 
#	option -p <password> password for basic HTTP authentication 
# 
 
require 5.004_04; 
#because that's the one that works with NT 
 
use strict; 
use vars qw($opt_i $opt_o $opt_c $opt_n $opt_u $opt_p); 
use Getopt::Std; 
use LWP::UserAgent; 
use URI::URL; 
use HTTP::Status; 
 
my ($user, $password); 
my ($cacheName); 
my $i_compressed; # inbound_compressed
my $o_compressed; # outbound_compressed
my $i_uncompressed; # inbound_uncompressed
my $o_uncompressed; # outbound_uncpmpressed 
my %tags; 
 
sub snarf { # html section 
   my($cache, $path) = @_; 
    my $url; 
    if (index($cache, 'http://') == 0) { 
		$url = url($cache); 
    } else { 
		$url = url('http://' . $cache); 
    } 
    $url->path($path);
    my $ua = new LWP::UserAgent;
     
    $ua->timeout(30);		# 30 second timeout 
    my $request = new HTTP::Request GET => $url; 
	$request->authorization_basic( $user, $password ); 
    $request->push_header('Pragma', 'no-cache'); 
    my $response = $ua->simple_request($request); 
    if ($response->is_success) { 
		if ($response->code != RC_OK) { 
			print STDERR "Could not GET ", $url, "\n"; 
		} else { 
			# split out into lines 
			my @lines = $response->content =~ m/^.*$/gmo; 
			# parse lines 
			my($tag, $value, $line);
			my @tags; 
			foreach $line (@lines) {
				$line =~ s/&nbsp;/ /g;
 
				$line =~ s/^\s+//;
				if ($line =~ "BDC:inbound-uncompressed~hourly") { 
					($tag, $value) = split("60, 60", $line);			 
					@tags = split(" ", $value);
					$i_uncompressed = $tags[60];
				}
				if ($line =~ "BDC:outbound-uncompressed~hourly") { 
					($tag, $value) = split("60, 60", $line);			
					@tags = split(" ", $value);
					$o_uncompressed = $tags[60];
				}
				if ($line =~ "BDC:inbound-compressed~hourly") { 
					($tag, $value) = split("60, 60", $line);			
					@tags = split(" ", $value);
					$i_compressed = $tags[60];
				}
				if ($line =~ "BDC:outbound-compressed~hourly") { 
					($tag, $value) = split("60, 60", $line);			
					@tags = split(" ", $value);
					$o_compressed = $tags[60];
				}
				 
			} 
		} 
		  
    } else { 
		print STDERR "Value ", $url, "\n"; 
    } 
    return; 
} 
 
sub help { 
    die "usage: $0 [-i|o] [-c|-n] [-u <username>] [-p <password>] ProxySG-IP[:port]\n"; 
} 
 
# MAIN 
if( @ARGV < 1 ) { 
	&help; 
} 
getopts('iocu:np:'); 
$user =			$opt_u; 
$password =		$opt_p; 
$cacheName = shift; 
 
if( $cacheName !~ m/:/ ) { 
	$cacheName .= ":8081"; 
}
 
snarf($cacheName, '/Console_urls/stats_mode=0' ); # obfuscated stats pages
if ($opt_n && $opt_i) { 
	snarf($cacheName, '/PDM/show-values/BDC:inbound-uncompressed~hourly');
	print "$i_uncompressed\n";
	}
if ($opt_n && $opt_o) {
	snarf($cacheName, '/PDM/show-values/BDC:outbound-uncompressed~hourly');
	print "$o_uncompressed\n";
	}
if ($opt_c && $opt_i) {
	snarf($cacheName, '/PDM/show-values/BDC:inbound-compressed~hourly');
	print "$i_compressed\n";
	}
if ($opt_c && $opt_o) {
	snarf($cacheName, '/PDM/show-values/BDC:outbound-compressed~hourly');
	print "$o_compressed\n";
	}
exit 0; 
